import React from 'react';
import './TaskList.css';

function TaskList(){

return(
<>
<div className='row task-head'>
TaskList
</div>

</>
);



}

export default TaskList;